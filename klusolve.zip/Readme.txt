KLUSolve 1.0, Copyright (c) 2008, EnerNex Corporation
All rights reserved.

KLU Version 1.0, May 31, 2007, by Timothy A. Davis and Ekanathan Palamadai.
Copyright (C) 2004-2007, University of Florida

CSparse: a Concise Sparse Matrix package.
Version 2.2.0, Copyright (c) 2006-2007, Timothy A. Davis, Mar 31, 2007.

AMD Version 2.2, Copyright (c) 2007 by Timothy A.
Davis, Patrick R. Amestoy, and Iain S. Duff.  All Rights Reserved.

BTF Version 1.0, May 31, 2007, by Timothy A. Davis
Copyright (C) 2004-2007, University of Florida

CZSparse, Copyright (c) 2008, EnerNex Corporation. All rights reserved.

==========================================================================

KLUSolve is a complex sparse matrix library tailored to electric power 
systems, licensed under LGPL version 2.1 (see files License.txt and 
lgpl_2_1.txt in this directory). For an example of use, see the OpenDSS 
project at www.sourceforge.net/projects/electricdss

Contact: Tom McDermott, tom at enernex dot com, or

  Tom McDermott
  EnerNex Corporation
  90 Clairton Boulevard, Suite A
  Pittsburgh, PA  15236
  1-412-653-0407

==========================================================================

KLUSolve is based on the KLU, CSparse, and supporting libraries developed
by Timothy A. Davis and his students, which are also licensed under LGPL 
version 2.1.  All source files used in KLUSolve are included in the 
SourceForge SVN repository for KLUSolve

Current versions: http://www.cise.ufl.edu/research/sparse

Contact: davis at cise dot ufl dot edu, or 

  Tim Davis, Professor
  Room E338 CSE Building
  P.O. Box 116120
  University of Florida
  Gainesville, FL 32611-6120
  1-352-392-1481

Reference Book: "Direct Methods for Sparse Linear Systems," Timothy A. Davis,
SIAM, Philadelphia, 2006.

